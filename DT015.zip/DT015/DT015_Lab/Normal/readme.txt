Public test data
